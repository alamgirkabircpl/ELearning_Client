import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToastNotificationService } from '../../../toast-notification.service';
import { Instructor } from '../../models/trainer';
import { User } from '../../models/user';
import { InstructorService } from '../../services/instructor.service';
import { UserService } from '../../services/users.service';

@Component({
    selector: 'app-instructor',
    standalone: true,
    imports: [CommonModule, FormsModule],
    templateUrl: './instructor.component.html',
    styleUrls: ['./instructor.component.scss'],
})
export class InstructorComponent {
    instructors: Instructor[] = [];
    instructor: Instructor = {
        id: '',
        firstName: '',
        lastName: '',
        qualification: '',
        isActive: false,
        email: '',
        userName: '',
        password: 'Test@123%',
        confirmPassword: 'Test@123%',
        linkdinProfile: 'Test@123%',
    };
    selectedFile: File | null = null;
    profileImagePreview: string | ArrayBuffer | null = null;
    showPassword = false;
    isSubmitting = false;
    toastService = inject(ToastNotificationService);

    constructor(
        private instructorService: InstructorService,
        private userService: UserService
    ) {}

    ngOnInit(): void {
        this.getAllInstructors();
    }

    getAllInstructors() {
        this.instructorService.getAll().subscribe({
            next: (res) => {
                this.instructors = res;
            },
            error: (err) => {
                console.error('Error fetching instructors:', err);
                this.toastService.showError('Failed to load instructors');
            },
        });
    }

    onFileSelected(event: Event) {
        const input = event.target as HTMLInputElement;
        if (input.files && input.files.length > 0) {
            this.selectedFile = input.files[0];

            // Create preview
            const reader = new FileReader();
            reader.onload = () => {
                this.profileImagePreview = reader.result;
            };
            reader.readAsDataURL(this.selectedFile);
        }
    }

    onSubmit() {
        console.log('Form submitted:', this.instructor);
        if (this.isSubmitting) return;

        this.isSubmitting = true;

        // // Validate passwords match
        if (this.instructor.password !== this.instructor.confirmPassword) {
            this.toastService.showError('Passwords do not match');
            this.isSubmitting = false;
            return;
        }

        // First create the user
        const userData: User = {
            firstName: this.instructor.firstName,
            lastName: this.instructor.lastName,
            email: this.instructor.email,
            userName: this.instructor.userName,
            password: this.instructor.password,
            confirmPassword: this.instructor.confirmPassword,
            isActive: true,
        };
        alert('I am user');
        this.userService.createUser(userData).subscribe({
            next: (userResponse) => {
                this.toastService.showSuccess('User created successfully');

                // Then create the instructor with profile picture
                const formData = new FormData();
                formData.append('firstName', this.instructor.firstName);
                formData.append('lastName', this.instructor.lastName);
                formData.append('qualification', this.instructor.qualification);
                formData.append('email', this.instructor.email);
                formData.append('userName', this.instructor.userName);
                if (this.instructor.linkdinProfile) {
                    formData.append(
                        'linkdinProfile',
                        this.instructor.linkdinProfile
                    );
                }
                if (this.selectedFile) {
                    formData.append('profilePicture', this.selectedFile);
                }

                if (this.instructor.id) {
                    // Update existing instructor
                    this.instructorService
                        .update(this.instructor.id, formData)
                        .subscribe({
                            next: () => {
                                this.toastService.showSuccess(
                                    'Instructor updated successfully'
                                );
                                this.getAllInstructors();
                                this.resetForm();
                            },
                            error: (err) => {
                                console.error(
                                    'Error updating instructor:',
                                    err
                                );
                                this.toastService.showError(
                                    'Failed to update instructor'
                                );
                            },
                            complete: () => {
                                this.isSubmitting = false;
                            },
                        });
                } else {
                    // Create new instructor
                    this.instructorService.create(formData).subscribe({
                        next: () => {
                            this.toastService.showSuccess(
                                'Instructor created successfully'
                            );
                            this.getAllInstructors();
                            this.resetForm();
                        },
                        error: (err) => {
                            console.error('Error creating instructor:', err);
                            this.toastService.showError(
                                'Failed to create instructor'
                            );
                        },
                        complete: () => {
                            this.isSubmitting = false;
                        },
                    });
                }
            },
            error: (err) => {
                console.error('Error creating user:', err);
                this.toastService.showError('Failed to create user');
                this.isSubmitting = false;
            },
        });
    }

    edit(ins: Instructor) {
        this.instructor = { ...ins };
        if (ins.profilePicture) {
            this.profileImagePreview = ins.profilePicture;
        }
    }

    delete(id?: string) {
        if (!id) return;

        if (confirm('Are you sure you want to delete this instructor?')) {
            this.instructorService.delete(id).subscribe({
                next: () => {
                    this.toastService.showSuccess(
                        'Instructor deleted successfully'
                    );
                    this.getAllInstructors();
                },
                error: (err) => {
                    console.error('Error deleting instructor:', err);
                    this.toastService.showError('Failed to delete instructor');
                },
            });
        }
    }

    resetForm() {
        this.instructor = {
            id: '',
            firstName: '',
            lastName: '',
            qualification: '',
            isActive: false,
            email: '',
            userName: '',
            password: '',
            confirmPassword: '',
            linkdinProfile: '',
        };
        this.selectedFile = null;
        this.profileImagePreview = null;
    }

    togglePasswordVisibility() {
        this.showPassword = !this.showPassword;
    }
}

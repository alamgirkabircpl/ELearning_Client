import { Component } from '@angular/core';

@Component({
  selector: 'app-user-roles',
  standalone: true,
  imports: [],
  templateUrl: './user-roles.component.html',
  styleUrl: './user-roles.component.css'
})
export class UserRolesComponent {

}

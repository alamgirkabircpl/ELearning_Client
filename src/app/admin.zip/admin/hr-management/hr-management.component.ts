import { Component } from '@angular/core';

@Component({
  selector: 'app-hr-management',
  standalone: true,
  imports: [],
  templateUrl: './hr-management.component.html',
  styleUrl: './hr-management.component.css'
})
export class HrManagementComponent {

}

export interface AssignCourse {
    courseAssignId: number;
    courseId: number;
    instructorDetailsId: number;
    courseUrl: string[];
    status: string | null;
    price: number;
    description: string;
}

export interface Instructor {
    instructorDetailsId: number;
    name: string;
    // Add other instructor properties as needed
}

export interface Course {
    courseId: number;
    name: string;
    // Add other course properties as needed
}
export interface Page<T> {
    items: T[];
    totalItems: number;
    currentPage: number;
    pageSize: number;
    totalPages: number;
}

import { Component, EventEmitter, inject, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../../auth.service';
import { ToastNotificationService } from '../../../toast-notification.service';

@Component({
    selector: 'app-navbar',
    standalone: true,
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css'],
})
export class NavbarComponent {
    @Input() isDark = false;
    @Output() toggleSidebar = new EventEmitter<void>();
    @Output() toggleDarkMode = new EventEmitter<void>();
    auth = inject(AuthService);
    route = inject(Router);
    toast = inject(ToastNotificationService);

    onToggleSidebar() {
        this.toggleSidebar.emit();
    }

    onToggleDarkMode() {
        this.toggleDarkMode.emit();
    }
    logout() {
        this.auth.logout().subscribe({
            complete: () => {
                // Redirect to login with a query parameter
                this.route.navigate(['/login'], {
                    queryParams: { loggedOut: 'true' },
                });
            },
        });
        this.toast.showSuccess('You are successfully logout.');
    }
}

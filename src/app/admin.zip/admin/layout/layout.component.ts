// admin-layout.component.ts
import { CommonModule } from '@angular/common';
import { Component, HostListener, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';

@Component({
    selector: 'app-admin-layout',
    standalone: true,
    imports: [
        CommonModule,
        RouterOutlet,
        NavbarComponent,
        SidebarComponent,
        FooterComponent,
        FormsModule,
    ],
    templateUrl: './layout.component.html',
    styleUrls: ['./layout.component.css'],
})
export class AdminLayoutComponent implements OnInit {
    isSidebarOpen = true; // Default to open
    isDark = false;
    isMobile = false;

    ngOnInit() {
        this.checkIfMobile();
        this.loadDarkModePreference();
    }

    @HostListener('window:resize')
    onResize() {
        this.checkIfMobile();
    }

    toggleSidebar() {
        this.isSidebarOpen = !this.isSidebarOpen;
    }

    closeSidebar() {
        if (this.isMobile) {
            this.isSidebarOpen = false;
        }
    }

    toggleDarkMode() {
        this.isDark = !this.isDark;
        localStorage.setItem('darkMode', this.isDark.toString());
    }

    private checkIfMobile() {
        this.isMobile = window.innerWidth < 768;
        // Remove the automatic closing of sidebar on desktop
        // Sidebar state will now persist across screen size changes
    }

    private loadDarkModePreference() {
        const savedMode = localStorage.getItem('darkMode') === 'true';
        this.isDark = savedMode;
    }
}

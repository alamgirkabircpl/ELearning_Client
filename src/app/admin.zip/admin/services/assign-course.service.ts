import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {
    AssignCourse,
    Course,
    Instructor,
    Page,
} from '../models/assign-course';

@Injectable({
    providedIn: 'root',
})
export class AssignCourseService {
    private baseUrl = 'http://localhost:44449/api/AssignCourse';

    constructor(private http: HttpClient) {}

    getAll(
        page: number = 1,
        pageSize: number = 10
    ): Observable<Page<AssignCourse>> {
        const params = new HttpParams()
            .set('page', page.toString())
            .set('pageSize', pageSize.toString());

        return this.http.get<Page<AssignCourse>>(`${this.baseUrl}/GetAll`, {
            params,
        });
    }

    create(assignCourse: AssignCourse): Observable<AssignCourse> {
        return this.http.post<AssignCourse>(
            `${this.baseUrl}/Create`,
            assignCourse
        );
    }

    update(assignCourse: AssignCourse): Observable<AssignCourse> {
        return this.http.put<AssignCourse>(
            `${this.baseUrl}/Update`,
            assignCourse
        );
    }

    delete(id: number): Observable<void> {
        return this.http.delete<void>(`${this.baseUrl}/Delete/${id}`);
    }

    // Mock methods for instructors and courses - replace with actual API calls
    getInstructors(): Observable<Instructor[]> {
        // Replace with actual API call to get instructors
        return this.http.get<Instructor[]>(
            'http://localhost:44449/api/Instructor/GetAll'
        );
    }

    getCourses(): Observable<Course[]> {
        // Replace with actual API call to get courses
        return this.http.get<Course[]>(
            'http://localhost:44449/api/Course/GetAll?PageNumber=1&PageSize=12'
        );
    }
}
